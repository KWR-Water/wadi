import os
import sys

sys.path.append('D:\\Users\\postvi\\Documents\\github\\wadi')
os.chdir('D:\\Users\\postvi\\Documents\\py\\test_wadi')

import wadi as wd

wdo = wd.DataObject(log_fname='ogor.log')

df0_kwargs = {
    "sheet_name": "OGOR.xls",
    "skiprows": 10,
    "usecols": "A:L",
    "datatype": "sampleinfo",
}

df1_kwargs = {
    "sheet_name": "OGOR.xls",
    "skiprows": 10,
    "usecols": "M:AY",
    "datatype": "feature",
}


wdo.file_reader(
    file_path="OGOR.xlsx",
    format="wide",
    extract_units_from_feature_name=True,
    blocks=[df0_kwargs, df1_kwargs],
)

df = wdo.get_converted_dataframe()

print(df.head())

df.to_excel("wadi_output/ogor_imported.xlsx")
